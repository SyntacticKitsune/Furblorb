SetLocation("A Clearing")
SetInventoryEnabled(false)