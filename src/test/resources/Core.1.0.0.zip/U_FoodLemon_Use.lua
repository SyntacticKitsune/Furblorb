Player:ApplyBuff(Buff.AttackDice(1, 2))
Player:ApplyBuff(Buff.DefenseDice(-1, 2))
