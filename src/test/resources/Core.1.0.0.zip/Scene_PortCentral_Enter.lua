SetLocation("South Finmer, Square")
SetInventoryEnabled(true)