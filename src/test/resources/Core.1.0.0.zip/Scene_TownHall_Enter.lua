SetLocation("North Finmer, Town Hall")
SetInventoryEnabled(false) -- re-enabled in OnLeave