SetInventoryEnabled(true)
SetLocation("Cliffside Rest")
