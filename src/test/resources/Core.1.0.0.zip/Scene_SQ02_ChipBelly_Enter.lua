SetLocation("Dire Wolf's Belly")
SetInventoryEnabled(false)