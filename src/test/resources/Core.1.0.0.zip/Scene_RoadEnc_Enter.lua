SetLocation("On the Road")
SetInventoryEnabled(false)