--[[

CHARACTER LIST
--------------

    Main:
Randall:    black wolf, m, bbeg
Iso:        pantheress, f, North Finmer mayor

    Support:
Canbell:    snow leopardess, f, North Finmer acting mayor
Rux:        red panda, m, adept, Iso's confidant
Gabe:       red fox, m, friendly fish merchant
Edgard:     german shepherd, m, North Finmer innkeep
Oliver:     lion, m, forester / carpenter
Stip:       tiger, m, Oliver's friend
Toby:       arctic fox, m, wrong place, wrong time
Gavin:      foxtaur, m, predator, inn regular
Venna:      vixen, f, manages the Club
Zosk:       chameleon, m, traveling merchant, provides mining supplies to Randall
Chip:       feral wolf, m, Rux's guard dog, SQ02 appearance
Pat:        stoat, m, shop owner
Willow:     rabbit, f, shrine tender

    Baddies:
Sahro:      tigress, f, RM member, MQ02 goon, MQ03 tavern
Mako:       husky, m, RM member, MQ02/MQ06
Mia:        husky, f, RM member, MQ03 temple
Jett:       rat, m, RM member, MQ05
Ethel:      bluebird, m, RM member, MQ05

    Mentioned:
Wilhelm:    tabby cat, m, mentioned in werewolf short story
Rosk:       chameleon, m, Zosk's brother

    OCs:
Rech:       [OC] crocodile, m, bouncer at Club
Vulpes:     [OC] fox, m, Club member
Carson:     [OC] otter, m, Club member
Tye:        [OC] wolf-deer hybrid, m, Club member
Phillip:    [OC] horse, m, Club member

]]