Player.Health = Player.Health + 3
