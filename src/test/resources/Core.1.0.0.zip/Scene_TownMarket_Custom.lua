-- The fish vendor is always a fox, because that was established in the werewolf short story.
-- However, we can randomly generate a fruit vendor.
local fruit_vendor = GetUniqueCharacter("town_fruit_vendor")
