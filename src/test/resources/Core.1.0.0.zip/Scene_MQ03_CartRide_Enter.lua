-- Can access inventory throughout the ride, not really any reason to forbid it
SetInventoryEnabled(true)
SetLocation("On the Road")
