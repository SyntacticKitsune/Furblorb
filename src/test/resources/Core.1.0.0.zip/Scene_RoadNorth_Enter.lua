SetLocation("Road near North Finmer")
SetInventoryEnabled(true)