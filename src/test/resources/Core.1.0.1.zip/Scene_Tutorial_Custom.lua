local tutorial_color = Color.Highlight
local instructor = GetRandomCharacter()
