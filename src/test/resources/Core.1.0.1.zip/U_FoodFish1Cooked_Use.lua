Player.Health = Player.Health + 6
Player:ApplyBuff(Buff.GrappleDice(1, 2))
