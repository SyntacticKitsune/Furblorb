SetLocation("Dalsida Abbey")
SetInventoryEnabled(true)
