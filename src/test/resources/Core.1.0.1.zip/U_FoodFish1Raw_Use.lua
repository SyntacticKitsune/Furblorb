Player.Health = Player.Health + 4
Player:ApplyBuff(Buff.GrappleDice(1, 2))
