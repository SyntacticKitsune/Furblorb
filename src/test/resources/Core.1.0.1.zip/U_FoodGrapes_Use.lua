Player.Health = Player.Health + 3
Player:ApplyBuff(Buff.SwallowDice(1, 2))
