SetLocation("South Finmer, Approach")
SetInventoryEnabled(true)