SetLocation("The Club")
SetInventoryEnabled(IsDevModeEnabled())