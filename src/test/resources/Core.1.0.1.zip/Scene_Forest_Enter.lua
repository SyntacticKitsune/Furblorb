SetLocation("Deep in the Forest")
SetInventoryEnabled(true)
Log("FOREST_ENTRY")
